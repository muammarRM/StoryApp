package com.dicoding.storyapp.view.adapter
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.storyapp.data.local.entity.Story
import com.dicoding.storyapp.databinding.ItemStoryBinding

class StoryViewHolder(private val binding: ItemStoryBinding) : RecyclerView.ViewHolder(binding.root) {
    fun bind(story: Story) {
        binding.titleTextView.text = story.title
        binding.root.setOnClickListener {
            // Handle item click and navigate to story detail
        }
    }
}