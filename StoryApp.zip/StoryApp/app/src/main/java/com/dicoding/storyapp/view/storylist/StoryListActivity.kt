package com.dicoding.storyapp.view.storylist

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp.databinding.ActivityStoryListBinding
import com.dicoding.storyapp.view.adapter.StoryAdapter
import com.dicoding.storyapp.view.ViewModelFactory
import com.dicoding.storyapp.view.addstory.AddStoryActivity

class StoryListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStoryListBinding
    private val viewModel by viewModels<StoryListViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var adapter: StoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeStoryList()

        // Set up action button to add new story
        binding.addStoryButton.setOnClickListener {
            // Navigate to AddStoryActivity to create new story
            startActivity(Intent(this, AddStoryActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = StoryAdapter()
        binding.storyRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.storyRecyclerView.adapter = adapter
    }

    private fun observeStoryList() {
        viewModel.getStories().observe(this) { stories ->
            adapter.submitList(stories)
        }
    }
}