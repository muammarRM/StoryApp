package com.dicoding.storyapp.data.local.entity

