package com.dicoding.storyapp.view.storylist

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.dicoding.storyapp.data.repository.StoryRepository
import com.dicoding.storyapp.data.local.entity.Story

class StoryListViewModel(private val repository: StoryRepository) : ViewModel() {
    fun getStories(): LiveData<List<Story>> {
        return repository.getAllStories().asLiveData()
    }
}
